<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fakultas extends CI_Controller 
{
    public function index()
    {
        $data = array(
                        'judul' => 'Fakultas',
                        'subjudul' => '',
                        'page' => 'fakultas/v_fakultas', //file page di folder view
                     );
        $this->load->view('v_template', $data, false); //buat template
     }
}